<?php
if(!class_exists('OP_Stock'))
{
    class OP_Stock{
        public function __construct()
        {

        }
        public function registers(){

        }
        public function delete($id){

        }
        public function save(){

        }
    }
}
?>