<html>
    <body>
        <h2><?php echo __('Hot Keys','openpos');?></h2>
        <ul>
            <li><span style="color:red;font-weight:bold;">F2</span> : <?php echo __('Focus barcode / product search','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F3</span> : <?php echo __('Focus customer search','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F4</span> : <?php echo __('Add new customer','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F5</span> : <?php echo __('Remove current customer','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F6</span> : <?php echo __('View current customer','openpos');?></li>
            
            <li><span style="color:red;font-weight:bold;">F8</span> : <?php echo __('Clear Cart','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F9</span> : <?php echo __('Goto checkout','openpos');?></li>
            <li><span style="color:red;font-weight:bold;">F10</span> : <?php echo __('Save Cart','openpos');?></li>

           

            <li><span style="color:red;font-weight:bold;">ESC</span> : <?php echo __('Close current Popup window','openpos');?></li>
        </ul>
    </body>
</html>